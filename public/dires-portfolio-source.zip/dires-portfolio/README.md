# Dires — Developer Portfolio

A modern, premium, fully responsive personal portfolio built with Next.js 16,
TypeScript, Tailwind CSS 4, Framer Motion, and an Express + Nodemailer backend.

## Features

- **Hero** with typewriter role rotation + static profile photo + colorful
  rotating gradient ring
- **About** with portrait, bio, animated stats counters, philosophy, and
  career timeline
- **Skills** organized into 6 categories (Frontend, Backend, Database,
  Mobile, Design & UX/UI, Foundations & Tools)
- **Services** — 6 service cards with 2D hover animations
- **Projects** — 4 projects in a 2x2 grid (AI Employee Recommendation,
  Expense Tracker Flutter, Evaluation Management, Library Documentation)
- **GitHub Stats** — live stats from the GitHub API with a languages bar
  chart and graceful fallback
- **Testimonials** — 3 cards with star ratings and reviewer info
- **Contact** — working form posting to an Express + Nodemailer backend
- **Ask about Dires** — floating AI chatbot that answers in any language
  (uses the z-ai-web-dev-sdk)
- **Animated 3D background** — cubes, polyhedrons, parallax orbs,
  butterflies, floating code symbols
- **Resume download** — ATS-friendly PDF generated at build time
- **Yellow hover underline** on navbar + active-section indicator
- **Performance-optimized** — GPU-friendly animations, reduced layer count,
  prefers-reduced-motion support

## Tech Stack

- Next.js 16 (App Router) + TypeScript 5
- Tailwind CSS 4 + shadcn/ui
- Framer Motion for animations
- Express.js + Nodemailer for the contact form
- Prisma ORM (SQLite) for any database needs
- z-ai-web-dev-sdk for the chatbot LLM

## Getting Started

1. Install dependencies:
   ```bash
   bun install
   ```

2. (Optional) Set up the contact service:
   ```bash
   cd mini-services/contact-service
   bun install
   cp .env.example .env   # then fill in SMTP credentials
   ```

3. Run the dev server:
   ```bash
   bun run dev
   ```
   Open http://localhost:3000

4. (Optional) Start the contact backend (separate terminal):
   ```bash
   cd mini-services/contact-service
   bun run dev
   ```
   The contact form posts to `/api/contact?XTransformPort=3001`
   (routed through Caddy). For local dev without Caddy, change the
   endpoint in `src/lib/portfolio-data.ts` to `http://localhost:3001/api/contact`.

## Customization

All content lives in `src/lib/portfolio-data.ts` — name, photo, bio,
skills, projects, services, testimonials, social links, contact info.
Update that one file to make the site your own.

The chatbot's system prompt (with portfolio context + strengths/weaknesses
analysis) is in `src/app/api/chat/route.ts`.

## Project Structure

```
src/
├─ app/
│  ├─ api/chat/route.ts        # Chatbot API (LLM via z-ai-web-dev-sdk)
│  ├─ globals.css              # Dark theme + custom utilities
│  ├─ layout.tsx
│  └─ page.tsx
├─ components/
│  ├─ portfolio/               # 20 portfolio components
│  └─ ui/                      # shadcn/ui component library
└─ lib/
   ├─ portfolio-data.ts        # All content (single source of truth)
   └─ utils.ts
mini-services/contact-service/  # Express + Nodemailer backend
prisma/schema.prisma
public/resume.pdf              # Generated ATS-friendly resume
```

## License

MIT — feel free to use this as a template for your own portfolio.
